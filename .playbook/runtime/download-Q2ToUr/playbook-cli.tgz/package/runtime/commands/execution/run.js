import fs from 'node:fs';
import path from 'node:path';
import { assignWorkersToLanes } from '@zachariahredfield/playbook-engine';
import { ExitCode } from '../../lib/cliContract.js';
import { emitCommandFailure, printCommandHelp } from '../../lib/commandSurface.js';
import { createCommandQualityTracker } from '../../lib/commandQuality.js';
const WORKSET_PLAN_PATH = '.playbook/workset-plan.json';
const EXECUTION_STATE_PATH = '.playbook/execution-state.json';
const readJsonArtifact = (cwd, artifactPath) => {
    const absolutePath = path.join(cwd, artifactPath);
    if (!fs.existsSync(absolutePath)) {
        return undefined;
    }
    const parsed = JSON.parse(fs.readFileSync(absolutePath, 'utf8'));
    if (parsed && typeof parsed === 'object' && 'data' in parsed) {
        return parsed.data;
    }
    return parsed;
};
const renderText = (runId, lanes, status) => {
    console.log('Playbook Execution Run');
    console.log('');
    console.log(`Run ID: ${runId}`);
    console.log('');
    console.log('Lanes:');
    for (const lane of lanes) {
        const marker = lane.state === 'completed' ? '✓' : '✗';
        console.log(`${marker} ${lane.lane_id} ${lane.state}`);
    }
    console.log('');
    console.log(`Execution status: ${status}`);
};
export const runExecution = async (cwd, options) => {
    if (options.help) {
        printCommandHelp({
            usage: 'playbook execute [options]',
            description: 'Execute orchestration lanes through the deterministic execution supervisor runtime.',
            options: ['--json                     Alias for --format=json', '--format <text|json>       Output format', '--quiet                    Suppress success output in text mode', '--help                     Show help'],
            artifacts: [EXECUTION_STATE_PATH]
        });
        return ExitCode.Success;
    }
    const tracker = createCommandQualityTracker(cwd, 'execute');
    try {
        const worksetPlan = readJsonArtifact(cwd, WORKSET_PLAN_PATH);
        if (!worksetPlan) {
            const exitCode = emitCommandFailure('execute', options, {
                summary: `Execution failed: missing prerequisite artifact ${WORKSET_PLAN_PATH}.`,
                findingId: 'execute.workset-plan.missing',
                message: `Missing required artifact: ${WORKSET_PLAN_PATH}.`,
                nextActions: ['Run `playbook orchestrate --tasks-file <path>` or `playbook orchestrate --goal "<goal>"` before execute.']
            });
            tracker.finish({ inputsSummary: 'missing workset plan', artifactsRead: [WORKSET_PLAN_PATH], successStatus: 'failure', warningsCount: 1 });
            return exitCode;
        }
        const engineModule = (await import('@zachariahredfield/playbook-engine'));
        if (!engineModule.startExecution || !engineModule.updateLaneState || !engineModule.recordWorkerResult || !engineModule.finalizeExecution) {
            throw new Error('playbook execute: execution supervisor exports are unavailable on this build.');
        }
        const run = await engineModule.startExecution(worksetPlan, cwd);
        const laneStateArtifact = path.join(cwd, EXECUTION_STATE_PATH);
        if (!fs.existsSync(laneStateArtifact)) {
            throw new Error('playbook execute: execution state artifact initialization failed.');
        }
        const laneInputs = worksetPlan.lanes.map((lane) => ({ ...lane }));
        const workerAssignments = assignWorkersToLanes({
            schemaVersion: '1.0',
            kind: 'lane-state',
            generatedAt: new Date(0).toISOString(),
            proposalOnly: true,
            workset_plan_path: WORKSET_PLAN_PATH,
            lanes: laneInputs.map((lane) => ({
                lane_id: lane.lane_id,
                task_ids: [...lane.task_ids].sort((a, b) => a.localeCompare(b)),
                status: lane.worker_ready ? 'ready' : 'blocked',
                readiness_status: lane.readiness_status ?? (lane.worker_ready ? 'ready' : 'blocked'),
                dependency_level: lane.dependency_level,
                dependencies_satisfied: lane.worker_ready,
                blocked_reasons: lane.worker_ready ? [] : ['worker prerequisites are not satisfied'],
                blocking_reasons: [...(lane.blocking_reasons ?? [])],
                conflict_surface_paths: [...(lane.conflict_surface_paths ?? [])],
                shared_artifact_risk: lane.shared_artifact_risk ?? 'low',
                assignment_confidence: lane.assignment_confidence ?? 0.5,
                verification_summary: { status: lane.worker_ready ? 'pending' : 'blocked', required_checks: [], optional_checks: [], notes: [] },
                merge_ready: false,
                worker_ready: lane.worker_ready
            })),
            blocked_lanes: laneInputs.filter((lane) => !lane.worker_ready).map((lane) => lane.lane_id).sort((a, b) => a.localeCompare(b)),
            ready_lanes: laneInputs.filter((lane) => lane.worker_ready).map((lane) => lane.lane_id).sort((a, b) => a.localeCompare(b)),
            running_lanes: [],
            completed_lanes: [],
            merge_ready_lanes: [],
            dependency_status: { total_edges: worksetPlan.dependency_edges.length, satisfied_edges: 0, unsatisfied_edges: worksetPlan.dependency_edges.length },
            merge_readiness: { merge_ready_lanes: [], not_merge_ready_lanes: [] },
            verification_status: { status: 'pending', lanes_pending_verification: [], lanes_blocked_from_verification: [] },
            warnings: []
        }, worksetPlan);
        const orderedAssignments = [...workerAssignments.lanes].sort((left, right) => left.lane_id.localeCompare(right.lane_id));
        for (const lane of orderedAssignments) {
            if (lane.status !== 'assigned') {
                await engineModule.updateLaneState(lane.lane_id, 'failed', cwd);
                await engineModule.recordWorkerResult(lane.lane_id, `worker-${lane.lane_id}`, { status: 'failed', retries: 1, summary: 'lane was not assignment-ready' }, cwd);
                continue;
            }
            await engineModule.updateLaneState(lane.lane_id, 'running', cwd);
            await engineModule.recordWorkerResult(lane.lane_id, `worker-${lane.lane_id}`, { status: 'completed', retries: 0, summary: 'deterministic execution success' }, cwd);
        }
        await engineModule.finalizeExecution(run.runId, cwd);
        const executionState = readJsonArtifact(cwd, EXECUTION_STATE_PATH);
        const lanes = Object.values(executionState?.lanes ?? {}).sort((left, right) => left.lane_id.localeCompare(right.lane_id));
        const status = executionState?.status === 'completed' ? 'SUCCESS' : executionState?.status === 'running' ? 'RUNNING' : 'FAILED';
        if (options.format === 'json') {
            console.log(JSON.stringify({
                schemaVersion: '1.0',
                command: 'execute',
                run_id: run.runId,
                execution_state_path: EXECUTION_STATE_PATH,
                lanes,
                execution_status: status
            }, null, 2));
            const exitCode = status === 'SUCCESS' ? ExitCode.Success : ExitCode.Failure;
            tracker.finish({
                inputsSummary: `lanes=${worksetPlan.lanes.length}`,
                artifactsRead: [WORKSET_PLAN_PATH],
                artifactsWritten: [EXECUTION_STATE_PATH],
                downstreamArtifactsProduced: [EXECUTION_STATE_PATH],
                successStatus: exitCode === ExitCode.Success ? 'success' : 'partial'
            });
            return exitCode;
        }
        if (!options.quiet) {
            renderText(run.runId, lanes, status);
        }
        const exitCode = status === 'SUCCESS' ? ExitCode.Success : ExitCode.Failure;
        tracker.finish({
            inputsSummary: `lanes=${worksetPlan.lanes.length}`,
            artifactsRead: [WORKSET_PLAN_PATH],
            artifactsWritten: [EXECUTION_STATE_PATH],
            downstreamArtifactsProduced: [EXECUTION_STATE_PATH],
            successStatus: exitCode === ExitCode.Success ? 'success' : 'partial'
        });
        return exitCode;
    }
    catch (error) {
        tracker.finish({
            inputsSummary: 'execution runtime failure',
            artifactsRead: [WORKSET_PLAN_PATH],
            artifactsWritten: [EXECUTION_STATE_PATH],
            successStatus: 'failure',
            warningsCount: 1
        });
        throw error;
    }
};
//# sourceMappingURL=run.js.map