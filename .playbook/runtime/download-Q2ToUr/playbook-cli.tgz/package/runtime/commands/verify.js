import * as engine from '@zachariahredfield/playbook-engine';
import { buildResult, emitResult, ExitCode } from '../lib/cliContract.js';
import { emitJsonOutput } from '../lib/jsonArtifact.js';
import { printCommandHelp } from '../lib/commandSurface.js';
import { loadVerifyRules } from '../lib/loadVerifyRules.js';
import { createCommandQualityTracker } from '../lib/commandQuality.js';
const resolveFailureGuidance = (verifyRules, failure) => {
    const rule = verifyRules.find((candidate) => candidate.check({ failure }));
    return {
        explanation: rule?.explanation,
        remediation: rule?.remediation ?? (failure.fix ? [failure.fix] : undefined)
    };
};
export const collectVerifyReport = async (cwd) => engine.verifyRepo(cwd);
const resolveRunId = (cwd, requestedRunId) => {
    if (requestedRunId) {
        return requestedRunId;
    }
    const latest = engine.getLatestMutableRun ? engine.getLatestMutableRun(cwd) : null;
    if (latest) {
        return latest.id;
    }
    const intent = engine.createExecutionIntent('verify repository governance', ['repository'], ['deterministic-cli-only-writes'], 'user');
    return engine.createExecutionRun(cwd, intent).id;
};
export const runVerify = async (cwd, options) => {
    if (options.help) {
        printCommandHelp({
            usage: 'playbook verify [options]',
            description: 'Verify repository governance rules and optional policy gating.',
            options: ['--policy                   Enable policy mode for configured policy rules', '--ci                       CI mode summary in text output', '--explain                  Show why findings matter and remediation in text mode', '--out <path>               Write JSON artifact envelope for verify result', '--run-id <id>              Attach verify step to an existing execution run', '--json                     Alias for --format=json', '--format <text|json>       Output format', '--quiet                    Suppress success output in text mode', '--help                     Show help'],
            artifacts: ['.playbook/findings*.json (optional via --out)', '.playbook/execution/runs/** (session runtime state)']
        });
        return ExitCode.Success;
    }
    const tracker = createCommandQualityTracker(cwd, 'verify');
    const verifyRules = await loadVerifyRules(cwd);
    const report = await collectVerifyReport(cwd);
    const { config } = await Promise.resolve(engine.loadConfig(cwd));
    const configuredPolicyRules = new Set(config.verify.policy.rules);
    const policyEvaluation = report.failures
        .map((failure) => {
        const rule = verifyRules.find((candidate) => candidate.check({ failure }));
        if (!rule?.policy) {
            return undefined;
        }
        if (!configuredPolicyRules.has(rule.policy.id)) {
            return undefined;
        }
        return {
            failureId: failure.id,
            policyId: rule.policy.id,
            ruleId: rule.id,
            message: failure.message,
            remediation: rule.remediation ?? (failure.fix ? [failure.fix] : undefined)
        };
    })
        .filter((policy) => Boolean(policy));
    const policyFailureIds = new Set(policyEvaluation.map((policy) => policy.failureId));
    const policyViolations = policyEvaluation
        .map((policy) => ({
        policyId: policy.policyId,
        ruleId: policy.ruleId,
        message: policy.message,
        remediation: policy.remediation
    }))
        .sort((left, right) => {
        const idDiff = left.policyId.localeCompare(right.policyId);
        if (idDiff !== 0) {
            return idDiff;
        }
        return left.message.localeCompare(right.message);
    });
    const inPolicyMode = options.policy;
    const ok = inPolicyMode ? policyViolations.length === 0 : report.ok;
    const exitCode = ok ? ExitCode.Success : ExitCode.PolicyFailure;
    const runId = resolveRunId(cwd, options.runId);
    const run = engine.appendExecutionStep(cwd, runId, {
        kind: 'verify',
        status: ok ? 'passed' : 'failed',
        inputs: { policyMode: inPolicyMode },
        outputs: {
            failures: report.failures.length,
            warnings: report.warnings.length,
            ok
        },
        evidence: [
            ...(options.outFile ? [{ id: 'evidence-findings-artifact', kind: 'artifact', ref: options.outFile }] : []),
            ...report.failures.map((failure, index) => ({
                id: `evidence-finding-${String(index + 1).padStart(3, '0')}`,
                kind: 'finding',
                ref: `verify.failure.${failure.id}`,
                note: failure.message
            }))
        ]
    });
    const runArtifactPath = engine.executionRunPath(cwd, runId);
    engine.attachSessionRunState(cwd, {
        step: 'verify',
        runId,
        goal: inPolicyMode ? 'verify repository policy posture' : 'verify repository governance',
        artifacts: [
            { artifact: runArtifactPath, kind: 'run' },
            ...(options.outFile ? [{ artifact: options.outFile, kind: 'finding' }] : [])
        ]
    });
    const hasApplyStep = run.steps.some((step) => step.kind === 'apply');
    if (hasApplyStep) {
        engine.completeExecutionRun(cwd, runId, ok
            ? { status: 'passed', summary: 'Remediation run completed and verification passed.' }
            : { status: 'partial', summary: 'Remediation run completed but verification failed.', failure_cause: 'verification_failed' });
    }
    if (options.format === 'text' && !options.ci && !options.explain && !inPolicyMode) {
        console.log(engine.formatHuman(report));
        tracker.finish({
            inputsSummary: `policy=${inPolicyMode ? 'on' : 'off'}`,
            artifactsWritten: options.outFile ? [options.outFile] : [],
            downstreamArtifactsProduced: options.outFile ? [options.outFile] : [],
            successStatus: ok ? 'success' : 'failure',
            warningsCount: report.warnings.length,
            confidenceScore: ok ? 0.9 : 0.3
        });
        return exitCode;
    }
    if (options.format === 'text' && options.ci && !options.explain && !inPolicyMode) {
        if (!options.quiet || !ok) {
            console.log(ok ? 'playbook verify: PASS' : 'playbook verify: FAIL');
        }
        tracker.finish({
            inputsSummary: `policy=${inPolicyMode ? 'on' : 'off'}`,
            artifactsWritten: options.outFile ? [options.outFile] : [],
            downstreamArtifactsProduced: options.outFile ? [options.outFile] : [],
            successStatus: ok ? 'success' : 'failure',
            warningsCount: report.warnings.length,
            confidenceScore: ok ? 0.9 : 0.3
        });
        return exitCode;
    }
    const resultPayload = {
        command: 'verify',
        ok,
        exitCode,
        summary: ok ? 'Verification passed.' : inPolicyMode ? 'Policy verification failed.' : 'Verification failed.',
        findings: [
            ...report.failures.map((failure) => ({
                ...resolveFailureGuidance(verifyRules, failure),
                id: inPolicyMode ? `verify.rule.${failure.id}` : `verify.failure.${failure.id}`,
                level: inPolicyMode ? (policyFailureIds.has(failure.id) ? 'error' : 'info') : 'error',
                message: failure.message
            })),
            ...report.warnings.map((warning) => ({
                id: `verify.warning.${warning.id}`,
                level: 'warning',
                message: warning.message
            }))
        ],
        nextActions: report.failures
            .map((failure) => failure.fix)
            .filter((fix) => Boolean(fix)),
        policyViolations: inPolicyMode ? policyViolations : undefined
    };
    if (options.format === 'json' && options.outFile) {
        emitJsonOutput({ cwd, command: 'verify', payload: buildResult(resultPayload), outFile: options.outFile });
        tracker.finish({
            inputsSummary: `policy=${inPolicyMode ? 'on' : 'off'}`,
            artifactsWritten: options.outFile ? [options.outFile] : [],
            downstreamArtifactsProduced: options.outFile ? [options.outFile] : [],
            successStatus: ok ? 'success' : 'failure',
            warningsCount: report.warnings.length,
            confidenceScore: ok ? 0.9 : 0.3
        });
        return exitCode;
    }
    emitResult({
        format: options.format,
        quiet: options.quiet,
        explain: options.explain,
        ...resultPayload
    });
    tracker.finish({
        inputsSummary: `policy=${inPolicyMode ? 'on' : 'off'}`,
        artifactsWritten: options.outFile ? [options.outFile] : [],
        downstreamArtifactsProduced: options.outFile ? [options.outFile] : [],
        successStatus: ok ? 'success' : 'failure',
        warningsCount: report.warnings.length,
        confidenceScore: ok ? 0.9 : 0.3
    });
    return exitCode;
};
//# sourceMappingURL=verify.js.map