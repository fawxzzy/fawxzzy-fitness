import { collectAnalyzeReport, ensureRepoIndex } from './analyze.js';
import { collectDoctorReport } from './doctor.js';
import { collectVerifyReport } from './verify.js';
import { ExitCode } from '../lib/cliContract.js';
import { loadAnalyzeRules } from '../lib/loadAnalyzeRules.js';
import { loadVerifyRules } from '../lib/loadVerifyRules.js';
import { buildFleetAdoptionReadinessSummary, buildFleetAdoptionWorkQueue, buildFleetCodexExecutionPlan, buildFleetExecutionReceipt, buildRepoAdoptionReadiness } from '@zachariahredfield/playbook-engine';
import fs from 'node:fs';
import path from 'node:path';
const EXECUTION_OUTCOME_INPUT_RELATIVE_PATH = path.join('.playbook', 'execution-outcome-input.json');
const defaultOutcomeInput = () => ({
    schemaVersion: '1.0',
    kind: 'fleet-adoption-execution-outcome-input',
    generated_at: new Date(0).toISOString(),
    session_id: 'unrecorded-session',
    prompt_outcomes: []
});
const readExecutionOutcomeInput = (cwd) => {
    const targetPath = path.join(cwd, EXECUTION_OUTCOME_INPUT_RELATIVE_PATH);
    if (!fs.existsSync(targetPath)) {
        return defaultOutcomeInput();
    }
    return JSON.parse(fs.readFileSync(targetPath, 'utf8'));
};
const readRepoIndexSummary = (cwd) => {
    const repoIndexPath = path.join(cwd, '.playbook', 'repo-index.json');
    if (!fs.existsSync(repoIndexPath)) {
        return null;
    }
    const raw = fs.readFileSync(repoIndexPath, 'utf8');
    const parsed = JSON.parse(raw);
    if (typeof parsed.framework !== 'string') {
        return null;
    }
    return {
        framework: parsed.framework,
        modules: Array.isArray(parsed.modules) ? parsed.modules.filter((value) => typeof value === 'string') : [],
        docs: Array.isArray(parsed.docs) ? parsed.docs.filter((value) => typeof value === 'string') : [],
        rules: Array.isArray(parsed.rules) ? parsed.rules.filter((value) => typeof value === 'string') : []
    };
};
const resolveTopIssue = async (cwd, verify, analyze) => {
    const failure = verify.failures[0];
    if (failure) {
        const matchingRule = (await loadVerifyRules(cwd)).find((rule) => rule.check({ failure }));
        if (matchingRule) {
            return { id: matchingRule.id, description: matchingRule.description };
        }
        return { id: failure.id, description: failure.message };
    }
    const warningRecommendation = analyze.recommendations.find((recommendation) => recommendation.severity === 'WARN');
    if (!warningRecommendation) {
        return null;
    }
    const matchingRule = (await loadAnalyzeRules()).find((rule) => rule.check({ recommendation: warningRecommendation }));
    if (matchingRule) {
        return { id: matchingRule.id, description: matchingRule.description };
    }
    return { id: warningRecommendation.id, description: warningRecommendation.title };
};
const toStatusResult = async (cwd) => {
    const doctor = await collectDoctorReport(cwd);
    const analyze = await collectAnalyzeReport(cwd);
    const verify = await collectVerifyReport(cwd);
    await ensureRepoIndex(analyze.repoPath);
    const warnings = analyze.recommendations.filter((rec) => rec.severity === 'WARN').length;
    const errors = 0;
    const environmentOk = doctor.status !== 'error';
    const result = {
        schemaVersion: '1.0',
        command: 'status',
        ok: doctor.status !== 'error' && verify.ok,
        environment: { ok: environmentOk },
        analysis: { warnings, errors },
        verification: { ok: verify.ok },
        summary: { warnings, errors },
        adoption: buildRepoAdoptionReadiness({ repoRoot: analyze.repoPath, connected: true })
    };
    const exitCode = verify.ok ? ExitCode.Success : ExitCode.PolicyFailure;
    return { result, exitCode, topIssue: await resolveTopIssue(cwd, verify, analyze), repoRoot: analyze.repoPath };
};
const toFleetStatusResult = (cwd) => {
    const registryPath = path.join(cwd, '.playbook', 'observer', 'repos.json');
    const registry = fs.existsSync(registryPath)
        ? JSON.parse(fs.readFileSync(registryPath, 'utf8'))
        : { repos: [{ id: 'current-repo', name: path.basename(cwd), root: cwd }] };
    const repos = Array.isArray(registry.repos) ? registry.repos : [];
    const fleet = buildFleetAdoptionReadinessSummary(repos.map((repo) => ({
        repo_id: repo.id,
        repo_name: repo.name,
        readiness: buildRepoAdoptionReadiness({ repoRoot: repo.root, connected: true })
    })));
    return {
        schemaVersion: '1.0',
        command: 'status',
        mode: 'fleet',
        fleet
    };
};
const toQueueStatusResult = (cwd) => {
    const fleet = toFleetStatusResult(cwd).fleet;
    return {
        schemaVersion: '1.0',
        command: 'status',
        mode: 'queue',
        queue: buildFleetAdoptionWorkQueue(fleet)
    };
};
const toExecutionStatusResult = (cwd) => {
    const queue = toQueueStatusResult(cwd).queue;
    return {
        schemaVersion: '1.0',
        command: 'status',
        mode: 'execute',
        execution_plan: buildFleetCodexExecutionPlan(queue)
    };
};
const toReceiptStatusResult = (cwd) => {
    const fleet = toFleetStatusResult(cwd).fleet;
    const queue = buildFleetAdoptionWorkQueue(fleet);
    const executionPlan = buildFleetCodexExecutionPlan(queue);
    return {
        schemaVersion: '1.0',
        command: 'status',
        mode: 'receipt',
        receipt: buildFleetExecutionReceipt(executionPlan, queue, fleet, readExecutionOutcomeInput(cwd))
    };
};
const printHuman = (result, ci, repoIndexSummary, topIssue) => {
    if (ci) {
        console.log(result.ok ? 'playbook status: PASS' : 'playbook status: FAIL');
        return;
    }
    console.log('Environment');
    console.log(result.environment.ok ? '  ✔ ok' : '  ✖ failed');
    if (repoIndexSummary) {
        console.log('');
        console.log('Project summary');
        console.log('────────────────');
        console.log('');
        console.log(`Framework: ${repoIndexSummary.framework}`);
        console.log(`Modules: ${repoIndexSummary.modules.length > 0 ? repoIndexSummary.modules.join(', ') : '-'}`);
        console.log(`Docs: ${repoIndexSummary.docs.length > 0 ? repoIndexSummary.docs.join(', ') : '-'}`);
        console.log(`Playbook rules: ${repoIndexSummary.rules.length}`);
    }
    console.log('');
    console.log('Repository Analysis');
    console.log(`  Warnings: ${result.analysis.warnings}`);
    console.log(`  Errors: ${result.analysis.errors}`);
    console.log('');
    console.log('Policy Verification');
    console.log(result.verification.ok ? '  ✔ ok' : '  ✖ failed');
    console.log('');
    console.log('Summary');
    console.log(`  Overall: ${result.ok ? 'healthy' : 'issues detected'}`);
    console.log(`  Warnings: ${result.summary.warnings}`);
    console.log(`  Errors: ${result.summary.errors}`);
    console.log('');
    console.log('Adoption readiness');
    console.log(`  Connection: ${result.adoption.connection_status}`);
    console.log(`  Playbook detected: ${result.adoption.playbook_detected ? 'yes' : 'no'}`);
    console.log(`  Lifecycle stage: ${result.adoption.lifecycle_stage}`);
    console.log(`  Fallback proof ready: ${result.adoption.fallback_proof_ready ? 'yes' : 'no'}`);
    console.log(`  Cross-repo eligible: ${result.adoption.cross_repo_eligible ? 'yes' : 'no'}`);
    if (result.adoption.blockers.length > 0) {
        console.log(`  Blockers: ${result.adoption.blockers.map((blocker) => blocker.code).join(', ')}`);
        console.log(`  Next command: ${result.adoption.recommended_next_steps[0] ?? 'n/a'}`);
    }
    if (topIssue) {
        console.log('');
        console.log('Top issue');
        console.log('─────────');
        console.log(`${topIssue.id} – ${topIssue.description}`);
        console.log('');
        console.log('Run:');
        console.log(`pnpm playbook explain ${topIssue.id}`);
    }
};
export const runStatus = async (cwd, options) => {
    try {
        if (options.scope === 'queue') {
            const queueResult = toQueueStatusResult(cwd);
            if (options.format === 'json') {
                console.log(JSON.stringify(queueResult, null, 2));
            }
            else {
                console.log(`Queue repos: ${queueResult.queue.total_repos}`);
                console.log(`Wave 1 actions: ${queueResult.queue.waves[0]?.action_count ?? 0}`);
                console.log(`Wave 2 actions: ${queueResult.queue.waves[1]?.action_count ?? 0}`);
                console.log(`Top lane: ${queueResult.queue.grouped_actions[0]?.parallel_group ?? 'n/a'}`);
            }
            return ExitCode.Success;
        }
        if (options.scope === 'fleet') {
            const fleetResult = toFleetStatusResult(cwd);
            if (options.format === 'json') {
                console.log(JSON.stringify(fleetResult, null, 2));
            }
            else {
                console.log(`Fleet repos: ${fleetResult.fleet.total_repos}`);
                console.log(`By stage: ${JSON.stringify(fleetResult.fleet.by_lifecycle_stage)}`);
                console.log(`Top action: ${fleetResult.fleet.recommended_actions[0]?.command ?? 'n/a'}`);
            }
            return ExitCode.Success;
        }
        if (options.scope === 'execute') {
            const executionResult = toExecutionStatusResult(cwd);
            if (options.format === 'json') {
                console.log(JSON.stringify(executionResult, null, 2));
            }
            else {
                const wave1 = executionResult.execution_plan.waves.find((wave) => wave.wave_id === 'wave_1');
                const wave2 = executionResult.execution_plan.waves.find((wave) => wave.wave_id === 'wave_2');
                console.log(`Execution plan kind: ${executionResult.execution_plan.kind}`);
                console.log(`Wave 1 repos: ${wave1?.repos.length ?? 0}`);
                console.log(`Wave 2 repos: ${wave2?.repos.length ?? 0}`);
                console.log(`Worker lanes: ${executionResult.execution_plan.worker_lanes.length}`);
                console.log(`Top prompt: ${executionResult.execution_plan.codex_prompts[0]?.prompt_id ?? 'n/a'}`);
            }
            return ExitCode.Success;
        }
        if (options.scope === 'receipt') {
            const receiptResult = toReceiptStatusResult(cwd);
            if (options.format === 'json') {
                console.log(JSON.stringify(receiptResult, null, 2));
            }
            else {
                console.log(`Execution receipt kind: ${receiptResult.receipt.kind}`);
                console.log(`Prompts total: ${receiptResult.receipt.verification_summary.prompts_total}`);
                console.log(`Succeeded: ${receiptResult.receipt.verification_summary.succeeded_count}`);
                console.log(`Failed: ${receiptResult.receipt.verification_summary.failed_count}`);
                console.log(`Partial: ${receiptResult.receipt.verification_summary.partial_count}`);
                console.log(`Drift: ${receiptResult.receipt.verification_summary.mismatch_count}`);
            }
            return ExitCode.Success;
        }
        const { result, exitCode, topIssue, repoRoot } = await toStatusResult(cwd);
        if (options.format === 'json') {
            console.log(JSON.stringify(result, null, 2));
            return exitCode;
        }
        if (!(options.quiet && result.ok)) {
            const repoIndexSummary = readRepoIndexSummary(repoRoot);
            printHuman(result, options.ci, repoIndexSummary, topIssue);
        }
        return exitCode;
    }
    catch (error) {
        if (options.format === 'json') {
            console.log(JSON.stringify({ schemaVersion: '1.0', command: 'status', ok: false, error: String(error) }, null, 2));
        }
        else {
            console.error('playbook status failed with an internal error.');
            console.error(String(error));
        }
        return ExitCode.Failure;
    }
};
//# sourceMappingURL=status.js.map