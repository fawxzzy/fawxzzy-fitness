import { runDocsAudit } from '@zachariahredfield/playbook-engine';
import { ExitCode } from '../lib/cliContract.js';
const printTextUsage = () => {
    console.log('Usage: playbook docs audit [--json] [--ci]');
};
const printHumanReport = (result) => {
    console.log(`playbook docs audit: ${result.status.toUpperCase()}`);
    console.log(`Findings: ${result.findings.length} (errors: ${result.summary.errors}, warnings: ${result.summary.warnings})`);
    const grouped = new Map();
    for (const finding of result.findings) {
        const entries = grouped.get(finding.ruleId) ?? [];
        entries.push(finding);
        grouped.set(finding.ruleId, entries);
    }
    for (const [ruleId, findings] of grouped.entries()) {
        console.log('');
        console.log(`Rule: ${ruleId}`);
        for (const finding of findings) {
            console.log(`- [${finding.level}] ${finding.message}`);
            console.log(`  path: ${finding.path}`);
            if (finding.suggestedDestination) {
                console.log(`  suggestedDestination: ${finding.suggestedDestination}`);
            }
            if (finding.recommendation) {
                console.log(`  recommendation: ${finding.recommendation}`);
            }
        }
    }
};
export const runDocs = async (cwd, commandArgs, options) => {
    const subcommand = commandArgs.find((arg) => !arg.startsWith('-'));
    if (subcommand !== 'audit') {
        if (!options.quiet) {
            printTextUsage();
        }
        return ExitCode.Failure;
    }
    const result = runDocsAudit(cwd);
    const payload = {
        schemaVersion: '1.0',
        command: 'docs audit',
        ...result
    };
    if (options.format === 'json') {
        console.log(JSON.stringify(payload, null, 2));
    }
    else if (!(options.quiet && result.ok)) {
        printHumanReport(result);
    }
    if (options.ci && result.summary.errors > 0) {
        return ExitCode.PolicyFailure;
    }
    return result.summary.errors > 0 ? ExitCode.Failure : ExitCode.Success;
};
//# sourceMappingURL=docs.js.map